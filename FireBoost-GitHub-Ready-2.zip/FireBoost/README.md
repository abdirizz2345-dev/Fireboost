# FireBoost v1
A simple Android gaming assistant for Free Fire.

Features:
- Boost checklist
- Gaming settings guide
- Device information
- 30-minute game timer

Build:
1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

This app does not claim to increase hardware FPS or bypass game protections.
