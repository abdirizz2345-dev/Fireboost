package com.fireboost.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView status, timerText;
    Handler handler = new Handler();
    long endTime = 0;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    TextView title(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setPadding(dp(16), dp(10), dp(16), dp(10)); return t;
    }

    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setTextSize(15); b.setAllCaps(false); b.setBackgroundColor(Color.rgb(40,40,40));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(dp(12), dp(7), dp(12), dp(7)); b.setLayoutParams(p); return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); showHome();
    }

    void base(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(15,15,15));
        root.addView(title("🔥 FIREBOOST", 25));
        root.addView(title(heading, 19));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showHome() {
        base("Gaming Assistant");
        TextView welcome = title("Prepare your phone for a better gaming session.", 16);
        welcome.setTextColor(Color.LTGRAY); content.addView(welcome);

        Button boost = btn("🚀  BOOST GAME");
        status = title("Ready. FireBoost uses safe settings and does not fake FPS gains.", 14);
        status.setTextColor(Color.GRAY); content.addView(status);
        content.addView(boost);
        Button settings = btn("⚙️  GAMING SETTINGS"); content.addView(settings);
        Button device = btn("📱  DEVICE INFO"); content.addView(device);
        Button timer = btn("⏱️  GAME TIMER"); content.addView(timer);

        boost.setOnClickListener(v -> boost());
        settings.setOnClickListener(v -> showSettings());
        device.setOnClickListener(v -> showDevice());
        timer.setOnClickListener(v -> showTimer());
    }

    void boost() {
        status.setText("Boost checklist complete: brightness, Do Not Disturb and battery-saving conflicts should be checked manually.");
        Toast.makeText(this, "FireBoost ready for gaming!", Toast.LENGTH_LONG).show();
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(Exception e) {}
    }

    void showSettings() {
        base("Gaming Settings");
        content.addView(title("Recommended starting point", 18));
        content.addView(title("• Use the highest stable FPS option available in Free Fire.\n\n• Close apps you are not using before playing.\n\n• Keep enough storage free.\n\n• Avoid playing while the phone is very hot.\n\n• Use a stable Wi‑Fi/mobile connection.\n\n• Do not install apps claiming to hack, inject, or bypass Free Fire protections.", 16));
        Button back=btn("← Back"); content.addView(back); back.setOnClickListener(v->showHome());
    }

    void showDevice() {
        base("Device Info");
        Runtime r=Runtime.getRuntime();
        long ramMB=(r.maxMemory()/1024/1024);
        content.addView(title("Android: " + Build.VERSION.RELEASE, 17));
        content.addView(title("Device: " + Build.MANUFACTURER + " " + Build.MODEL, 17));
        content.addView(title("Available app memory: " + ramMB + " MB", 17));
        content.addView(title("CPU cores: " + r.availableProcessors(), 17));
        Button back=btn("← Back"); content.addView(back); back.setOnClickListener(v->showHome());
    }

    void showTimer() {
        base("Game Timer");
        timerText=title("00:00", 36); timerText.setGravity(Gravity.CENTER); content.addView(timerText);
        Button start=btn("▶ Start 30-minute session"); content.addView(start);
        Button back=btn("← Back"); content.addView(back);
        start.setOnClickListener(v->{ endTime=System.currentTimeMillis()+30*60*1000; tick(); });
        back.setOnClickListener(v->showHome());
    }

    void tick() {
        long left=Math.max(0,endTime-System.currentTimeMillis());
        long sec=left/1000; timerText.setText(String.format(Locale.US,"%02d:%02d",sec/60,sec%60));
        if(left>0) handler.postDelayed(this::tick,1000); else Toast.makeText(this,"Session finished.",Toast.LENGTH_LONG).show();
    }
}
